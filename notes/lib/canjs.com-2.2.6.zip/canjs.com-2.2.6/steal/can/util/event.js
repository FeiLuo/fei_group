/*!
 * CanJS - 2.2.6
 * http://canjs.com/
 * Copyright (c) 2015 Bitovi
 * Wed, 20 May 2015 23:00:01 GMT
 * Licensed MIT
 */

/*can@2.2.6#util/event*/
steal('can/util/can.js', 'can/event', function (can) {
	// # can/util/event
	// This imports can/event for API compatibility.
	return can;
});

