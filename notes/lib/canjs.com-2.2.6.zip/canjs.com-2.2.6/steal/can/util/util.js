/*!
 * CanJS - 2.2.6
 * http://canjs.com/
 * Copyright (c) 2015 Bitovi
 * Wed, 20 May 2015 23:00:01 GMT
 * Licensed MIT
 */

/*can@2.2.6#util/util*/
// comments are in func.js for documentation purposes.
steal('can/util/jquery', function (can) {
	return can;
});

