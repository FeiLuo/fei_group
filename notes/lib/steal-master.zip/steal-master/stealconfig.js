steal.config({
	paths: {
		"steal/*" : "../*.js",
		"@traceur": "traceur/traceur.js"
	}
});
