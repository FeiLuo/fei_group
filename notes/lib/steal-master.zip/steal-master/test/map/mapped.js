steal(function(){
	return {name: "map"};
});
