steal("./steal-style.css!", function(){
	return {};
});
