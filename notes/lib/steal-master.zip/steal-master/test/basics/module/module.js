define(["basics/es6module"],function(es6){
	return {
		name: "module",
		es6module: es6["default"]
	};
});
