System.config({
	transpiler: "babel"
});
