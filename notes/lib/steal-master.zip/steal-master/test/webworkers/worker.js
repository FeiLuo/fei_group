var dep = require("./dep");

global.postMessage(dep);

