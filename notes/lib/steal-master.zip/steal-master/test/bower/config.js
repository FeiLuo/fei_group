require("bower.json!bower");
