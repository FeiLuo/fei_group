require("bower.json!bower");

System.config({
	paths: {
		"lodash": "lodash.js"
	}
});
