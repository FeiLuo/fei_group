
exports.myModule = "lodash";
