steal("../module", "tests/mod/widget",function(m, w){
	return {
		module: m,
		widget: w,
		name: "mod"
	};
});
