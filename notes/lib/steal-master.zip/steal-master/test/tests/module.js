steal("./bar", function(bar){
	return {
	  bar: bar,
	  name: "module.js"
	};
});