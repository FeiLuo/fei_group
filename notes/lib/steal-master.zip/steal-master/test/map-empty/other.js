define([], function() {
	throw "This should have been ignored";
});
