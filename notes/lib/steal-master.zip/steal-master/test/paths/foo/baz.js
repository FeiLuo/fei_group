steal(function(){
	return "it works";
});
