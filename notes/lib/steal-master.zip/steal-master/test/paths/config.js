steal.config({
	paths: {
		"steal/dev/*" : "../../dev/*.js",
		"bar/*": "../paths/*.js"
	}
});
