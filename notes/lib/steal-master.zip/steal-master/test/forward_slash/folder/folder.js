export var foo = "bar";
